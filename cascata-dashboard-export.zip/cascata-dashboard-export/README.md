# Cascata Test Dashboard - Integration Guide

This package contains all files needed to integrate the Cascata Test Dashboard into your portal.

## Files Included

1. **CascataTest.tsx** - Frontend React component
2. **bigquery-functions.ts** - Backend BigQuery query functions
3. **router-endpoints.ts** - tRPC router endpoints (for reference)
4. **route-config.ts** - Route configuration (for reference)
5. **navigation-config.ts** - Navigation menu configuration (for reference)

## Integration Steps

### Step 1: Add Frontend Component

Copy `CascataTest.tsx` to your frontend:
```
client/src/pages/playground/CascataTest.tsx
```

### Step 2: Add Backend BigQuery Functions

Add the functions from `bigquery-functions.ts` to your BigQuery playground module (or create one):
```
server/bigquery-playground.ts
```

Make sure to export:
- `getHubSpotContacts`
- `getHubSpotDeals`
- `HubSpotContact`
- `HubSpotContactsResponse`
- `HubSpotDeal`
- `HubSpotDealsResponse`

### Step 3: Add tRPC Router Endpoints

Add the endpoints from `router-endpoints.ts` to your dashboard router:
```
server/routers/dashboard-router.ts
```

Add under the `playground` router:
- `cascataTest` endpoint
- `cascataTestDeals` endpoint

### Step 4: Add Route Configuration

Add the route from `route-config.ts` to your App.tsx:
```
client/src/App.tsx
```

1. Add lazy import:
```typescript
const CascataTest = lazyWithRetry(() => import("./pages/playground/CascataTest"));
```

2. Add route:
```typescript
<Route path={"/playground/cascata-test"}>
  <ProtectedRoute requiredSection="playground">
    <ErrorBoundary>
      <Suspense fallback={<RouteLoadingFallback />}>
        <CascataTest />
      </Suspense>
    </ErrorBoundary>
  </ProtectedRoute>
</Route>
```

### Step 5: Add Navigation Menu Item

Add the menu item from `navigation-config.ts` to your DashboardLayout:
```
client/src/components/DashboardLayout.tsx
```

Add to `playgroundMenuItems`:
```typescript
{ path: "/playground/cascata-test", label: "Cascata Test Dashboard", icon: Database }
```

### Step 6: Verify Dependencies

Ensure you have these UI components available:
- Card, CardContent, CardHeader, CardTitle
- Table, TableBody, TableCell, TableHead, TableHeader, TableRow
- Button
- Popover, PopoverContent, PopoverTrigger
- RadioGroup, RadioGroupItem
- Input
- ScrollArea
- Label
- Skeleton

And these icons from lucide-react:
- Columns

### Step 7: BigQuery Configuration

The dashboard queries these BigQuery tables:
- `reporting-299920.hubspot.contact`
- `reporting-299920.hubspot.deal`
- `reporting-299920.hubspot.deal_stage`

Update the project ID (`reporting-299920`) to match your BigQuery project if different.

### Step 8: Build and Test

1. Build your application
2. Navigate to `/playground/cascata-test`
3. Verify the dashboard loads and displays data correctly

## Notes

- The dashboard requires access to the "playground" section
- Admin users can refresh data (though refresh button is currently hidden)
- Default values are highlighted in yellow
- The dashboard uses server-side pagination (25 rows per page)

## Troubleshooting

If you encounter issues:
1. Check browser console for errors
2. Verify BigQuery credentials and project access
3. Ensure all UI components are properly imported
4. Verify tRPC endpoints are correctly registered
5. Check that route paths match your routing configuration
