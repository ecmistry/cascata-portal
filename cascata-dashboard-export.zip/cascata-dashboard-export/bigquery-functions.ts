/**
 * BigQuery Functions for Cascata Test Dashboard
 * Add these functions to your server/bigquery-playground.ts file
 */

import { logger } from "./_core/logger";
import { query, type BigQueryRow, bigquery } from "./bigquery-core";
import { normalizeBigQueryRows } from "@shared/bigquery-utils";
import { paginateQueryWithLimit, type PaginatedResult } from "./bigquery-pagination";

/**
 * HubSpot Contact interface
 */
export interface HubSpotContact extends BigQueryRow {
  [key: string]: unknown;
}

export interface HubSpotContactsResponse extends PaginatedResult<HubSpotContact> {}

/**
 * Get HubSpot contacts with pagination
 * Filters out deleted contacts (_fivetran_deleted = false)
 */
export async function getHubSpotContacts(
  page: number = 1,
  pageSize: number = 25,
  bypassCache: boolean = false
): Promise<HubSpotContactsResponse> {
  try {
    logger.info("[BigQuery Playground] Querying HubSpot contacts", { page, pageSize, bypassCache });

    const queryString = `
      SELECT *
      FROM \`reporting-299920.hubspot.contact\`
      WHERE _fivetran_deleted = false
    `;

    const result = await paginateQueryWithLimit<HubSpotContact>(
      queryString,
      { page, pageSize },
      bypassCache
    );

    // Normalize rows to handle BigQuery types
    const normalizedData = normalizeBigQueryRows(result.data);

    logger.info("[BigQuery Playground] HubSpot contacts query completed", {
      page: result.pagination.page,
      pageSize: result.pagination.pageSize,
      totalResults: result.pagination.totalResults,
      totalPages: result.pagination.totalPages,
      resultsInPage: normalizedData.length,
    });

    return {
      data: normalizedData,
      pagination: result.pagination,
    };
  } catch (error: unknown) {
    const err = error instanceof Error ? error : new Error(String(error));
    logger.error("[BigQuery Playground] Error in getHubSpotContacts", err);
    throw err;
  }
}

/**
 * HubSpot Deal interface
 */
export interface HubSpotDeal extends BigQueryRow {
  [key: string]: unknown;
  deal_stage_value?: string; // Added for the joined field
}

export interface HubSpotDealsResponse extends PaginatedResult<HubSpotDeal> {}

/**
 * Get HubSpot deals with pagination
 * Includes LEFT JOIN with deal_stage table to get deal_stage_value
 */
export async function getHubSpotDeals(
  page: number = 1,
  pageSize: number = 25,
  bypassCache: boolean = false
): Promise<HubSpotDealsResponse> {
  try {
    logger.info("[BigQuery Playground] Querying HubSpot deals with deal_stage join", { page, pageSize, bypassCache });

    const queryString = `
      SELECT
        d.*,
        ds.value AS deal_stage_value
      FROM \`reporting-299920.hubspot.deal\` d
      LEFT JOIN \`reporting-299920.hubspot.deal_stage\` ds
        ON d.deal_id = ds.deal_id
    `;

    const result = await paginateQueryWithLimit<HubSpotDeal>(
      queryString,
      { page, pageSize },
      bypassCache
    );

    // Normalize rows to handle BigQuery types
    const normalizedData = normalizeBigQueryRows(result.data);

    logger.info("[BigQuery Playground] HubSpot deals query completed", {
      page: result.pagination.page,
      pageSize: result.pagination.pageSize,
      totalResults: result.pagination.totalResults,
      totalPages: result.pagination.totalPages,
      resultsInPage: normalizedData.length,
    });

    return {
      data: normalizedData,
      pagination: result.pagination,
    };
  } catch (error: unknown) {
    const err = error instanceof Error ? error : new Error(String(error));
    logger.error("[BigQuery Playground] Error in getHubSpotDeals", err);
    throw err;
  }
}
