import { db } from '../config/database.js';
import { hubspotDeals } from '../db/schema.js';
import { logger } from '../utils/logger.js';
import { parseHubSpotDate } from '../utils/date-utils.js';
import {
  getAllObjects,
  getRecentlyModifiedObjects,
} from './hubspot-api.js';
import {
  initializeSyncState,
  isFirstSync,
  getLastSyncTimestampWithBuffer,
  markSyncRunning,
  updateSyncState,
  markSyncFailed,
} from './sync-state.js';
import { syncConfig } from '../config/hubspot.js';

interface HubSpotDeal {
  id: string;
  properties: {
    dealname?: string;
    dealstage?: string;
    pipeline?: string;
    amount?: string;
    closedate?: string;
    createdate?: string;
    lastmodifieddate?: string;
    hs_lastmodifieddate?: string;
    hubspot_owner_id?: string;
    dealtype?: string;
    [key: string]: any;
  };
}

const DEAL_PROPERTIES = [
  'dealname',
  'dealstage',
  'pipeline',
  'amount',
  'closedate',
  'createdate',
  'lastmodifieddate',
  'hs_lastmodifieddate',
  'hubspot_owner_id',
  'dealtype',
];

/**
 * Transform HubSpot deal to database format
 */
function transformDeal(deal: HubSpotDeal) {
  const props = deal.properties;
  
  return {
    id: deal.id,
    dealname: props.dealname || null,
    dealstage: props.dealstage || null,
    pipeline: props.pipeline || null,
    amount: props.amount ? props.amount : null,
    closedate: parseHubSpotDate(props.closedate),
    createdate: parseHubSpotDate(props.createdate),
    lastmodifieddate: parseHubSpotDate(props.lastmodifieddate),
    hsLastmodifieddate: props.hs_lastmodifieddate ? parseInt(props.hs_lastmodifieddate) : null,
    hubspotOwnerId: props.hubspot_owner_id || null,
    dealtype: props.dealtype || null,
    propertiesJson: props,
    syncedAt: new Date(),
    updatedAt: new Date(),
  };
}

/**
 * Upsert deals into database
 */
async function upsertDeals(deals: HubSpotDeal[]): Promise<void> {
  if (deals.length === 0) return;
  
  logger.info(`Upserting ${deals.length} deals`);
  
  // Process in batches
  const batchSize = syncConfig.batchSize;
  
  for (let i = 0; i < deals.length; i += batchSize) {
    const batch = deals.slice(i, i + batchSize);
    const transformedBatch = batch.map(transformDeal);
    
    try {
      // Use INSERT ... ON DUPLICATE KEY UPDATE
      for (const deal of transformedBatch) {
        await db
          .insert(hubspotDeals)
          .values(deal)
          .onDuplicateKeyUpdate({
            set: {
              dealname: deal.dealname,
              dealstage: deal.dealstage,
              pipeline: deal.pipeline,
              amount: deal.amount,
              closedate: deal.closedate,
              createdate: deal.createdate,
              lastmodifieddate: deal.lastmodifieddate,
              hsLastmodifieddate: deal.hsLastmodifieddate,
              hubspotOwnerId: deal.hubspotOwnerId,
              dealtype: deal.dealtype,
              propertiesJson: deal.propertiesJson,
              syncedAt: deal.syncedAt,
              updatedAt: deal.updatedAt,
            },
          });
      }
      
      logger.debug(`Upserted batch of ${batch.length} deals`);
    } catch (error) {
      logger.error(`Failed to upsert deals batch`, error);
      throw error;
    }
  }
}

/**
 * Perform full sync of all deals
 */
async function fullSync(): Promise<number> {
  logger.info('Starting full sync of deals');
  
  const deals = await getAllObjects<HubSpotDeal>('deals', DEAL_PROPERTIES);
  
  await upsertDeals(deals);
  
  logger.info(`Full sync completed: ${deals.length} deals`);
  return deals.length;
}

/**
 * Perform incremental sync of modified deals
 */
async function incrementalSync(sinceTimestamp: number): Promise<number> {
  logger.info('Starting incremental sync of deals', { sinceTimestamp });
  
  const deals = await getRecentlyModifiedObjects<HubSpotDeal>(
    'deals',
    DEAL_PROPERTIES,
    sinceTimestamp
  );
  
  await upsertDeals(deals);
  
  logger.info(`Incremental sync completed: ${deals.length} deals`);
  return deals.length;
}

/**
 * Sync deals from HubSpot to MariaDB
 */
export async function syncDeals(): Promise<void> {
  const objectType = 'deals';
  
  try {
    logger.info('=== Starting deals sync ===');
    
    // Initialize sync state if needed
    await initializeSyncState(objectType);
    
    // Mark sync as running
    await markSyncRunning(objectType);
    
    // Check if this is the first sync
    const firstSync = await isFirstSync(objectType);
    
    let recordsSynced: number;
    
    if (firstSync) {
      recordsSynced = await fullSync();
    } else {
      const lastSyncTimestamp = await getLastSyncTimestampWithBuffer(
        objectType,
        syncConfig.bufferMinutes
      );
      
      if (lastSyncTimestamp) {
        recordsSynced = await incrementalSync(lastSyncTimestamp);
      } else {
        // Fallback to full sync if timestamp is missing
        recordsSynced = await fullSync();
      }
    }
    
    // Update sync state
    await updateSyncState(objectType, recordsSynced, 'success');
    
    logger.info('=== Deals sync completed successfully ===', { recordsSynced });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    await markSyncFailed(objectType, errorMessage);
    logger.error('=== Deals sync failed ===', error);
    throw error;
  }
}
