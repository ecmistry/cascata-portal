import { hubspotConfig } from '../config/hubspot.js';
import { logger } from '../utils/logger.js';

interface RateLimitTracker {
  requests: number[];
  windowMs: number;
}

const rateLimitTracker: RateLimitTracker = {
  requests: [],
  windowMs: hubspotConfig.rateLimit.windowMs,
};

/**
 * Check and enforce rate limiting
 */
function checkRateLimit(): void {
  const now = Date.now();
  const windowStart = now - rateLimitTracker.windowMs;
  
  // Remove requests outside the current window
  rateLimitTracker.requests = rateLimitTracker.requests.filter(
    (timestamp) => timestamp > windowStart
  );
  
  // Check if we're at the limit
  if (rateLimitTracker.requests.length >= hubspotConfig.rateLimit.requestsPerWindow) {
    const oldestRequest = rateLimitTracker.requests[0];
    const waitTime = oldestRequest + rateLimitTracker.windowMs - now;
    
    if (waitTime > 0) {
      logger.warn(`Rate limit approaching, waiting ${waitTime}ms`);
      // In a real implementation, you might want to use a proper delay mechanism
      // For now, we'll just log the warning
    }
  }
  
  rateLimitTracker.requests.push(now);
}

/**
 * Make a request to HubSpot API with retry logic
 */
async function makeRequest<T>(
  url: string,
  options: RequestInit = {},
  retries = 3
): Promise<T> {
  checkRateLimit();
  
  const headers = {
    'Authorization': `Bearer ${hubspotConfig.apiKey}`,
    'Content-Type': 'application/json',
    ...options.headers,
  };

  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const response = await fetch(url, { ...options, headers });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HubSpot API error: ${response.status} ${response.statusText} - ${errorText}`);
      }
      
      return await response.json() as T;
    } catch (error) {
      logger.warn(`Request failed (attempt ${attempt + 1}/${retries})`, { url, error });
      
      if (attempt === retries - 1) {
        throw error;
      }
      
      // Exponential backoff
      const delay = Math.pow(2, attempt) * 1000;
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  
  throw new Error('Max retries exceeded');
}

/**
 * Search for objects using HubSpot Search API
 */
export async function searchObjects<T>(
  objectType: string,
  filters: any[],
  properties: string[],
  after?: number
): Promise<{ results: T[]; paging?: { next?: { after: string } } }> {
  const url = `${hubspotConfig.baseUrl}/crm/v3/objects/${objectType}/search`;
  
  const body = {
    filterGroups: filters.length > 0 ? [{ filters }] : undefined,
    properties,
    sorts: [
      {
        propertyName: 'hs_lastmodifieddate',
        direction: 'ASCENDING',
      },
    ],
    limit: 100,
    after: after?.toString(),
  };
  
  logger.debug(`Searching ${objectType}`, { filters, after });
  
  return makeRequest<{ results: T[]; paging?: { next?: { after: string } } }>(url, {
    method: 'POST',
    body: JSON.stringify(body),
  });
}

/**
 * Get all objects with pagination
 */
export async function getAllObjects<T>(
  objectType: string,
  properties: string[],
  limit = 100
): Promise<T[]> {
  const allResults: T[] = [];
  let after: string | undefined;
  
  do {
    const url = new URL(`${hubspotConfig.baseUrl}/crm/v3/objects/${objectType}`);
    url.searchParams.set('limit', limit.toString());
    url.searchParams.set('properties', properties.join(','));
    
    if (after) {
      url.searchParams.set('after', after);
    }
    
    logger.debug(`Fetching ${objectType}`, { after, limit });
    
    const response = await makeRequest<{
      results: T[];
      paging?: { next?: { after: string } };
    }>(url.toString());
    
    allResults.push(...response.results);
    after = response.paging?.next?.after;
    
    logger.info(`Fetched ${response.results.length} ${objectType}, total: ${allResults.length}`);
  } while (after);
  
  return allResults;
}

/**
 * Get all pipelines for an object type
 */
export async function getPipelines(objectType: string): Promise<any[]> {
  const url = `${hubspotConfig.baseUrl}/crm/v3/pipelines/${objectType}`;
  
  logger.debug(`Fetching pipelines for ${objectType}`);
  
  const response = await makeRequest<{ results: any[] }>(url);
  return response.results;
}

/**
 * Get recently modified objects using Search API
 */
export async function getRecentlyModifiedObjects<T>(
  objectType: string,
  properties: string[],
  sinceTimestamp: number
): Promise<T[]> {
  const allResults: T[] = [];
  let after: number | undefined;
  
  do {
    const filters = [
      {
        propertyName: 'hs_lastmodifieddate',
        operator: 'GTE',
        value: sinceTimestamp.toString(),
      },
    ];
    
    const response = await searchObjects<T>(objectType, filters, properties, after);
    
    allResults.push(...response.results);
    after = response.paging?.next?.after ? parseInt(response.paging.next.after) : undefined;
    
    logger.info(`Fetched ${response.results.length} modified ${objectType}, total: ${allResults.length}`);
  } while (after);
  
  return allResults;
}
