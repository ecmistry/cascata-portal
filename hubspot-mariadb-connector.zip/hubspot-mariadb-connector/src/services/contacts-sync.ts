import { db } from '../config/database.js';
import { hubspotContacts } from '../db/schema.js';
import { logger } from '../utils/logger.js';
import { parseHubSpotDate } from '../utils/date-utils.js';
import {
  getAllObjects,
  getRecentlyModifiedObjects,
} from './hubspot-api.js';
import {
  initializeSyncState,
  isFirstSync,
  getLastSyncTimestampWithBuffer,
  markSyncRunning,
  updateSyncState,
  markSyncFailed,
} from './sync-state.js';
import { syncConfig } from '../config/hubspot.js';

interface HubSpotContact {
  id: string;
  properties: {
    email?: string;
    firstname?: string;
    lastname?: string;
    phone?: string;
    company?: string;
    website?: string;
    lifecyclestage?: string;
    jobtitle?: string;
    createdate?: string;
    lastmodifieddate?: string;
    hs_lastmodifieddate?: string;
    [key: string]: any;
  };
}

const CONTACT_PROPERTIES = [
  'email',
  'firstname',
  'lastname',
  'phone',
  'company',
  'website',
  'lifecyclestage',
  'jobtitle',
  'createdate',
  'lastmodifieddate',
  'hs_lastmodifieddate',
];

/**
 * Transform HubSpot contact to database format
 */
function transformContact(contact: HubSpotContact) {
  const props = contact.properties;
  
  return {
    id: contact.id,
    email: props.email || null,
    firstname: props.firstname || null,
    lastname: props.lastname || null,
    phone: props.phone || null,
    company: props.company || null,
    website: props.website || null,
    lifecyclestage: props.lifecyclestage || null,
    jobtitle: props.jobtitle || null,
    createdate: parseHubSpotDate(props.createdate),
    lastmodifieddate: parseHubSpotDate(props.lastmodifieddate),
    hsLastmodifieddate: props.hs_lastmodifieddate ? parseInt(props.hs_lastmodifieddate) : null,
    propertiesJson: props,
    syncedAt: new Date(),
    updatedAt: new Date(),
  };
}

/**
 * Upsert contacts into database
 */
async function upsertContacts(contacts: HubSpotContact[]): Promise<void> {
  if (contacts.length === 0) return;
  
  logger.info(`Upserting ${contacts.length} contacts`);
  
  // Process in batches
  const batchSize = syncConfig.batchSize;
  
  for (let i = 0; i < contacts.length; i += batchSize) {
    const batch = contacts.slice(i, i + batchSize);
    const transformedBatch = batch.map(transformContact);
    
    try {
      // Use INSERT ... ON DUPLICATE KEY UPDATE
      for (const contact of transformedBatch) {
        await db
          .insert(hubspotContacts)
          .values(contact)
          .onDuplicateKeyUpdate({
            set: {
              email: contact.email,
              firstname: contact.firstname,
              lastname: contact.lastname,
              phone: contact.phone,
              company: contact.company,
              website: contact.website,
              lifecyclestage: contact.lifecyclestage,
              jobtitle: contact.jobtitle,
              createdate: contact.createdate,
              lastmodifieddate: contact.lastmodifieddate,
              hsLastmodifieddate: contact.hsLastmodifieddate,
              propertiesJson: contact.propertiesJson,
              syncedAt: contact.syncedAt,
              updatedAt: contact.updatedAt,
            },
          });
      }
      
      logger.debug(`Upserted batch of ${batch.length} contacts`);
    } catch (error) {
      logger.error(`Failed to upsert contacts batch`, error);
      throw error;
    }
  }
}

/**
 * Perform full sync of all contacts
 */
async function fullSync(): Promise<number> {
  logger.info('Starting full sync of contacts');
  
  const contacts = await getAllObjects<HubSpotContact>('contacts', CONTACT_PROPERTIES);
  
  await upsertContacts(contacts);
  
  logger.info(`Full sync completed: ${contacts.length} contacts`);
  return contacts.length;
}

/**
 * Perform incremental sync of modified contacts
 */
async function incrementalSync(sinceTimestamp: number): Promise<number> {
  logger.info('Starting incremental sync of contacts', { sinceTimestamp });
  
  const contacts = await getRecentlyModifiedObjects<HubSpotContact>(
    'contacts',
    CONTACT_PROPERTIES,
    sinceTimestamp
  );
  
  await upsertContacts(contacts);
  
  logger.info(`Incremental sync completed: ${contacts.length} contacts`);
  return contacts.length;
}

/**
 * Sync contacts from HubSpot to MariaDB
 */
export async function syncContacts(): Promise<void> {
  const objectType = 'contacts';
  
  try {
    logger.info('=== Starting contacts sync ===');
    
    // Initialize sync state if needed
    await initializeSyncState(objectType);
    
    // Mark sync as running
    await markSyncRunning(objectType);
    
    // Check if this is the first sync
    const firstSync = await isFirstSync(objectType);
    
    let recordsSynced: number;
    
    if (firstSync) {
      recordsSynced = await fullSync();
    } else {
      const lastSyncTimestamp = await getLastSyncTimestampWithBuffer(
        objectType,
        syncConfig.bufferMinutes
      );
      
      if (lastSyncTimestamp) {
        recordsSynced = await incrementalSync(lastSyncTimestamp);
      } else {
        // Fallback to full sync if timestamp is missing
        recordsSynced = await fullSync();
      }
    }
    
    // Update sync state
    await updateSyncState(objectType, recordsSynced, 'success');
    
    logger.info('=== Contacts sync completed successfully ===', { recordsSynced });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    await markSyncFailed(objectType, errorMessage);
    logger.error('=== Contacts sync failed ===', error);
    throw error;
  }
}
