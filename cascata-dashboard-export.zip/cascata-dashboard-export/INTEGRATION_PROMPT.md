# Cascata Test Dashboard - Integration Prompt

Use this prompt to integrate the Cascata Test Dashboard into your new portal:

---

## Integration Request

I need to integrate the Cascata Test Dashboard into this portal. The dashboard allows users to configure HubSpot field mappings for Contacts and Deals objects.

### Files to Add:

1. **Frontend Component**: `CascataTest.tsx` - A React component that displays a configuration table with questions, property selection, column selection dropdowns, and default values.

2. **Backend BigQuery Functions**: Functions to query HubSpot contacts and deals from BigQuery:
   - `getHubSpotContacts()` - Queries `reporting-299920.hubspot.contact` table with pagination
   - `getHubSpotDeals()` - Queries `reporting-299920.hubspot.deal` table with LEFT JOIN to `deal_stage` table
   - Includes TypeScript interfaces: `HubSpotContact`, `HubSpotContactsResponse`, `HubSpotDeal`, `HubSpotDealsResponse`

3. **tRPC Router Endpoints**: Two endpoints under the playground router:
   - `cascataTest` - Calls `getHubSpotContacts`
   - `cascataTestDeals` - Calls `getHubSpotDeals`
   - Both support pagination (page, pageSize) and cache bypass options

4. **Route Configuration**: Add route `/playground/cascata-test` that:
   - Uses lazy loading
   - Requires "playground" section access
   - Wraps in ErrorBoundary and Suspense

5. **Navigation Menu**: Add menu item "Cascata Test Dashboard" to playground section with Database icon

### Key Features:

- **Model Configuration Table**: Displays questions for Contacts and Deals objects
- **Column Selection**: Searchable dropdowns for selecting HubSpot fields
- **Default Values**: Pre-configured default field mappings (highlighted in yellow)
- **Server-side Pagination**: 25 rows per page
- **BigQuery Integration**: Queries HubSpot tables with proper joins

### Dependencies:

- React hooks (useState, useMemo, useEffect)
- tRPC for API calls
- Shadcn/ui components (Card, Table, Button, Popover, RadioGroup, Input, ScrollArea, Label)
- Lucide React icons (Columns)
- BigQuery client library
- Pagination utilities

### BigQuery Tables Used:

- `reporting-299920.hubspot.contact` (filtered by `_fivetran_deleted = false`)
- `reporting-299920.hubspot.deal`
- `reporting-299920.hubspot.deal_stage` (LEFT JOIN for deal_stage_value)

**Note**: Update the project ID (`reporting-299920`) if your BigQuery project is different.

### Default Field Mappings:

**Contacts:**
- SQL date: `property_admin_first_became_a_sql_date`
- Teams: `property_admin_pod`
- SQL types: `property_sql_type`
- Conversion date: `property_admin_first_became_an_opportunity_date`

**Deals:**
- Teams: `property_deal_geo_pods`
- Opportunity types: `property_dealtype`
- ARR field: `property_amount_in_home_currency`
- SQL association: `property_type_of_sql_associated_to_deal`
- Close date: `property_closedate`
- Deal won: `deal_stage_value` (from joined deal_stage table, non-configurable)

Please integrate all files and ensure:
1. All imports resolve correctly
2. Routes are properly configured
3. Navigation menu item appears
4. BigQuery queries execute successfully
5. UI components render correctly

---

