/**
 * tRPC Router Endpoints for Cascata Test Dashboard
 * Add these endpoints to your server/routers/dashboard-router.ts
 * Under the playground router
 */

// Add these imports at the top of dashboard-router.ts if not already present:
// import { z } from "zod";
// import { publicProcedure, router } from "../trpc";

// Add these endpoints under the playground router:

cascataTest: publicProcedure
  .input(
    z
      .object({
        page: z.number().int().min(1).default(1),
        pageSize: z.number().int().min(1).max(100).default(25),
        bypassCache: z.boolean().optional(),
      })
      .optional()
  )
  .query(async ({ input }) => {
    const page = input?.page ?? 1;
    const pageSize = input?.pageSize ?? 25;
    const bypassCache = input?.bypassCache ?? false;
    return await bigquery.getHubSpotContacts(page, pageSize, bypassCache);
  }),

cascataTestDeals: publicProcedure
  .input(
    z
      .object({
        page: z.number().int().min(1).default(1),
        pageSize: z.number().int().min(1).max(100).default(25),
        bypassCache: z.boolean().optional(),
      })
      .optional()
  )
  .query(async ({ input }) => {
    const page = input?.page ?? 1;
    const pageSize = input?.pageSize ?? 25;
    const bypassCache = input?.bypassCache ?? false;
    return await bigquery.getHubSpotDeals(page, pageSize, bypassCache);
  }),
